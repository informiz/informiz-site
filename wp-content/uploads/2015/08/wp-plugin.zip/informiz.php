<?php  
/* 
Plugin Name: Informiz 
Plugin URI: http://informiz.org 
Version: 0.1 
Author: Nira Amit 
Description: Pre-alpha version of the Informiz wordpress plugin
*/  

defined( 'ABSPATH' ) or die( 'Plugin file cannot be accessed directly.' );

function informiz_scripts() {
	wp_register_script('bpopup', plugins_url('jquery.bpopup.min.js', __FILE__), array('jquery'),'0.11.0.min', true);
	wp_register_script('dotimeout', plugins_url('doTimeout.js', __FILE__), array('jquery'),'1.0', true);
	wp_register_script('tipso', plugins_url('tipso.js', __FILE__), array('jquery'),'0.11.0.min', true);
	wp_register_script('informiz', plugins_url('informiz.js', __FILE__), array('jquery', 'bpopup', 'tipso'),'0.1', true);
	wp_register_style('iz-common', plugins_url('iz_common.css', __FILE__));
	wp_register_style('informiz-style', plugins_url('informiz.css', __FILE__));
	wp_register_style('tipso-style', plugins_url('tipso.css', __FILE__));
}
add_action( 'wp_enqueue_scripts', 'informiz_scripts' );


$informiz_init = FALSE;
function informiz_shortcode( $atts, $content )
{
	if (! $GLOBALS['informiz_init']) {
		wp_enqueue_script('bpopup');
		wp_enqueue_script('dotimeout');
		wp_enqueue_script('tipso');
		wp_enqueue_style('tipso-style');
		wp_enqueue_script('informiz');
		wp_enqueue_style('informiz-style');
		wp_enqueue_style('iz-common');
		$GLOBALS['informiz_init'] = TRUE;
	}
	
	$a = shortcode_atts( array(
		'inf_media'=>'',
		'inf_source'=>'',
		'land_media'=>'',
		'land_source'=>''), $atts );

	return '<span class="iz-informitip" data-inf-media="' . esc_attr($a['inf_media']) . '" data-inf-src="' . esc_attr($a['inf_source']) . '" data-land-media="' . esc_attr($a['land_media']) . '" data-land-src="' . esc_attr($a['land_source']) . '">' . $content . '</span>';
}
add_shortcode( 'informiz', 'informiz_shortcode' );

function informiz_add_tooltip($content)
{
	if (! $GLOBALS['informiz_init']) {
		return $content;
	}
	$logo = plugins_url('informiz.png', __FILE__);
	$img =  plugins_url('magnifying.png', __FILE__);
	$tooltip = <<<EOT
	<div id="iz-tip-wrapper" style="display:none"><div class="iz_dialog">
		<div class="iz_header">
			<img class="iz_logo" src="$logo" alt="logo"/>
		</div>
		<section class= "iz_query">
			<img class="iz_magnifying" src="$img" alt="magnifying"/>
			<p class="iz_title"></p>
		</section>
		<div class="iz_bordered">
			<h3>Author selected:</h3>
			<button type="button" class="iz_informi iz_button" title="" >Informi</button>
			<button type="button" class="iz_landscape iz_button" title="" >Landscape</button>
		</div>
		<div class="iz_bordered">
			<h3>Search:</h3>
			<button type="button" class="iz_button" disabled>Under construction...</button>
		</div>
	</div></div>
	<div id="informipop" class="bpop_container">
	</div>
	<div id="landscapepop" class="bpop_container">
	</div>
EOT;
	return $content . $tooltip;
}
add_filter('the_content', 'informiz_add_tooltip', 99);